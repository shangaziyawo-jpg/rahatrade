import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import accountRouter from "./account";
import assetsRouter from "./assets";
import marketRouter from "./market";
import tradesRouter from "./trades";
import depositsRouter from "./deposits";
import withdrawalsRouter from "./withdrawals";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/auth", authRouter);
router.use("/account", accountRouter);
router.use("/assets", assetsRouter);
router.use("/market", marketRouter);
router.use("/trades", tradesRouter);
router.use("/deposits", depositsRouter);
router.use("/withdrawals", withdrawalsRouter);

export default router;
