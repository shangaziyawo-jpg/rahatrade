import { Router } from "express";
import { db, usersTable, withdrawalsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { requireAuth, type AuthRequest } from "../middlewares/requireAuth";
import { z } from "zod";

const router = Router();

const withdrawSchema = z.object({
  amount: z.number().min(100),
  mpesaPhone: z.string().min(9),
});

router.get("/", requireAuth, async (req: AuthRequest, res) => {
  const withdrawals = await db
    .select()
    .from(withdrawalsTable)
    .where(eq(withdrawalsTable.userId, req.userId!))
    .orderBy(desc(withdrawalsTable.createdAt))
    .limit(20);

  res.json(
    withdrawals.map((w) => ({
      id: w.id,
      amount: parseFloat(w.amount),
      mpesaPhone: w.mpesaPhone,
      status: w.status,
      createdAt: w.createdAt.toISOString(),
    }))
  );
});

router.post("/", requireAuth, async (req: AuthRequest, res) => {
  const parsed = withdrawSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }

  const { amount, mpesaPhone } = parsed.data;

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, req.userId!))
    .limit(1);

  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const currentBalance = parseFloat(user.balance);
  if (currentBalance < amount) {
    res.status(400).json({ error: "Insufficient balance" });
    return;
  }

  const newBalance = (currentBalance - amount).toFixed(2);
  await db.update(usersTable).set({ balance: newBalance }).where(eq(usersTable.id, req.userId!));

  const [withdrawal] = await db
    .insert(withdrawalsTable)
    .values({
      userId: req.userId!,
      amount: amount.toFixed(2),
      mpesaPhone,
      status: "pending",
    })
    .returning();

  setTimeout(async () => {
    try {
      await db
        .update(withdrawalsTable)
        .set({ status: "completed" })
        .where(eq(withdrawalsTable.id, withdrawal.id));
    } catch {
    }
  }, 10000);

  res.status(201).json({
    id: withdrawal.id,
    amount: parseFloat(withdrawal.amount),
    mpesaPhone: withdrawal.mpesaPhone,
    status: withdrawal.status,
    createdAt: withdrawal.createdAt.toISOString(),
  });
});

export default router;
