import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, type AuthRequest } from "../middlewares/requireAuth";

const router = Router();

router.get("/balance", requireAuth, async (req: AuthRequest, res) => {
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.userId!)).limit(1);
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  res.json({
    balance: parseFloat(user.balance),
    currency: "KES",
    accountType: user.accountType,
    totalDeposited: parseFloat(user.totalDeposited),
    totalPayout: parseFloat(user.totalPayout),
    totalLost: parseFloat(user.totalLost),
  });
});

export default router;
