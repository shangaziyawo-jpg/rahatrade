import { Router } from "express";
import { db, assetsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/", async (_req, res) => {
  const assets = await db.select().from(assetsTable).where(eq(assetsTable.isActive, true));
  res.json(
    assets.map((a) => ({
      id: a.id,
      name: a.name,
      symbol: a.symbol,
      currentPrice: parseFloat(a.currentPrice),
      change: parseFloat(a.change),
      changePercent: parseFloat(a.changePercent),
      isActive: a.isActive,
    }))
  );
});

export default router;
