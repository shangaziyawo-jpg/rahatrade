import { Router } from "express";
import { db, usersTable, tradesTable, assetsTable } from "@workspace/db";
import { eq, and, desc } from "drizzle-orm";
import { requireAuth, type AuthRequest } from "../middlewares/requireAuth";
import { z } from "zod";

const router = Router();

const placeTradeSchema = z.object({
  assetId: z.number().int().positive(),
  direction: z.enum(["UP", "DOWN"]),
  amount: z.number().min(10),
  duration: z.number().int().positive(),
});

const PAYOUT_PERCENT = 85;

router.post("/", requireAuth, async (req: AuthRequest, res) => {
  const parsed = placeTradeSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }

  const { assetId, direction, amount, duration } = parsed.data;

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.userId!)).limit(1);
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  if (parseFloat(user.balance) < amount) {
    res.status(400).json({ error: "Insufficient balance" });
    return;
  }

  const [asset] = await db.select().from(assetsTable).where(eq(assetsTable.id, assetId)).limit(1);
  if (!asset) {
    res.status(400).json({ error: "Asset not found" });
    return;
  }

  const entryPrice = parseFloat(asset.currentPrice);
  const payout = parseFloat((amount * (1 + PAYOUT_PERCENT / 100)).toFixed(2));
  const expiresAt = new Date(Date.now() + duration * 1000);

  // Deduct balance
  const newBalance = (parseFloat(user.balance) - amount).toFixed(2);
  await db.update(usersTable).set({ balance: newBalance, totalLost: (parseFloat(user.totalLost) + amount).toFixed(2) }).where(eq(usersTable.id, req.userId!));

  const [trade] = await db
    .insert(tradesTable)
    .values({
      userId: req.userId!,
      assetId,
      assetName: asset.name,
      assetSymbol: asset.symbol,
      direction,
      amount: amount.toFixed(2),
      payout: payout.toFixed(2),
      payoutPercent: PAYOUT_PERCENT.toFixed(2),
      entryPrice: entryPrice.toFixed(4),
      currentPrice: entryPrice.toFixed(4),
      duration,
      status: "open",
      expiresAt,
    })
    .returning();

  // Schedule trade resolution
  setTimeout(async () => {
    try {
      const [latestAsset] = await db.select().from(assetsTable).where(eq(assetsTable.id, assetId)).limit(1);
      const closingPrice = parseFloat(latestAsset?.currentPrice ?? entryPrice.toFixed(4));
      const drift = (Math.random() - 0.48) * 0.01;
      const finalPrice = closingPrice + drift;

      const won =
        direction === "UP" ? finalPrice > entryPrice : finalPrice < entryPrice;
      const status = won ? "won" : "lost";

      const [usr] = await db.select().from(usersTable).where(eq(usersTable.id, req.userId!)).limit(1);
      if (usr) {
        if (won) {
          const updatedBalance = (parseFloat(usr.balance) + payout).toFixed(2);
          const updatedPayout = (parseFloat(usr.totalPayout) + payout).toFixed(2);
          const updatedLost = (parseFloat(usr.totalLost) - amount).toFixed(2);
          await db.update(usersTable).set({ balance: updatedBalance, totalPayout: updatedPayout, totalLost: updatedLost }).where(eq(usersTable.id, req.userId!));
        }
      }

      await db
        .update(tradesTable)
        .set({
          status,
          closingPrice: finalPrice.toFixed(4),
          currentPrice: finalPrice.toFixed(4),
          result: won ? "win" : "loss",
          closedAt: new Date(),
        })
        .where(eq(tradesTable.id, trade.id));
    } catch {
      // silent
    }
  }, duration * 1000);

  res.status(201).json({
    id: trade.id,
    assetName: trade.assetName,
    assetSymbol: trade.assetSymbol,
    direction: trade.direction,
    amount: parseFloat(trade.amount),
    payout: parseFloat(trade.payout),
    payoutPercent: parseFloat(trade.payoutPercent),
    entryPrice: parseFloat(trade.entryPrice),
    currentPrice: trade.currentPrice ? parseFloat(trade.currentPrice) : null,
    closingPrice: null,
    status: trade.status,
    result: null,
    expiresAt: trade.expiresAt.toISOString(),
    closedAt: null,
    createdAt: trade.createdAt.toISOString(),
  });
});

function formatTrade(t: typeof tradesTable.$inferSelect) {
  return {
    id: t.id,
    assetName: t.assetName,
    assetSymbol: t.assetSymbol,
    direction: t.direction,
    amount: parseFloat(t.amount),
    payout: parseFloat(t.payout),
    payoutPercent: parseFloat(t.payoutPercent),
    entryPrice: parseFloat(t.entryPrice),
    currentPrice: t.currentPrice ? parseFloat(t.currentPrice) : null,
    closingPrice: t.closingPrice ? parseFloat(t.closingPrice) : null,
    status: t.status,
    result: t.result ?? null,
    expiresAt: t.expiresAt.toISOString(),
    closedAt: t.closedAt?.toISOString() ?? null,
    createdAt: t.createdAt.toISOString(),
  };
}

router.get("/open", requireAuth, async (req: AuthRequest, res) => {
  const trades = await db
    .select()
    .from(tradesTable)
    .where(and(eq(tradesTable.userId, req.userId!), eq(tradesTable.status, "open")))
    .orderBy(desc(tradesTable.createdAt));
  res.json(trades.map(formatTrade));
});

router.get("/summary", requireAuth, async (req: AuthRequest, res) => {
  const trades = await db
    .select()
    .from(tradesTable)
    .where(and(eq(tradesTable.userId, req.userId!)));

  const closedTrades = trades.filter((t) => t.status !== "open");
  const wonTrades = closedTrades.filter((t) => t.status === "won");
  const totalStaked = trades.reduce((s, t) => s + parseFloat(t.amount), 0);
  const totalPayout = wonTrades.reduce((s, t) => s + parseFloat(t.payout), 0);

  res.json({
    totalTrades: closedTrades.length,
    wonTrades: wonTrades.length,
    lostTrades: closedTrades.length - wonTrades.length,
    winRate: closedTrades.length > 0 ? Math.round((wonTrades.length / closedTrades.length) * 100 * 10) / 10 : 0,
    totalStaked: Math.round(totalStaked * 100) / 100,
    totalPayout: Math.round(totalPayout * 100) / 100,
    netProfit: Math.round((totalPayout - totalStaked) * 100) / 100,
  });
});

router.get("/", requireAuth, async (req: AuthRequest, res) => {
  const trades = await db
    .select()
    .from(tradesTable)
    .where(eq(tradesTable.userId, req.userId!))
    .orderBy(desc(tradesTable.createdAt))
    .limit(50);
  res.json(trades.map(formatTrade));
});

export default router;
