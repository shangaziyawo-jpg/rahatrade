import { Router } from "express";
import { db, usersTable, depositsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { requireAuth, type AuthRequest } from "../middlewares/requireAuth";
import { z } from "zod";

const router = Router();

const depositSchema = z.object({
  amount: z.number().min(100),
  mpesaPhone: z.string().min(10),
});

router.get("/", requireAuth, async (req: AuthRequest, res) => {
  const deposits = await db
    .select()
    .from(depositsTable)
    .where(eq(depositsTable.userId, req.userId!))
    .orderBy(desc(depositsTable.createdAt))
    .limit(20);

  res.json(
    deposits.map((d) => ({
      id: d.id,
      amount: parseFloat(d.amount),
      mpesaPhone: d.mpesaPhone,
      status: d.status,
      createdAt: d.createdAt.toISOString(),
    }))
  );
});

router.post("/", requireAuth, async (req: AuthRequest, res) => {
  const parsed = depositSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }

  const { amount, mpesaPhone } = parsed.data;

  const [deposit] = await db
    .insert(depositsTable)
    .values({
      userId: req.userId!,
      amount: amount.toFixed(2),
      mpesaPhone,
      status: "pending",
    })
    .returning();

  // Simulate deposit completion after 5 seconds
  setTimeout(async () => {
    try {
      await db.update(depositsTable).set({ status: "completed" }).where(eq(depositsTable.id, deposit.id));
      const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.userId!)).limit(1);
      if (user) {
        const newBalance = (parseFloat(user.balance) + amount).toFixed(2);
        const newDeposited = (parseFloat(user.totalDeposited) + amount).toFixed(2);
        await db.update(usersTable).set({ balance: newBalance, totalDeposited: newDeposited }).where(eq(usersTable.id, req.userId!));
      }
    } catch {
      // silent
    }
  }, 5000);

  res.status(201).json({
    id: deposit.id,
    amount: parseFloat(deposit.amount),
    mpesaPhone: deposit.mpesaPhone,
    status: deposit.status,
    createdAt: deposit.createdAt.toISOString(),
  });
});

export default router;
