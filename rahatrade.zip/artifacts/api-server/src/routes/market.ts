import { Router } from "express";
import { db, assetsTable, priceHistoryTable } from "@workspace/db";
import { eq, desc, and } from "drizzle-orm";

const router = Router();

// Generate simulated price data for chart
function generatePriceHistory(basePrice: number, points: number): { timestamp: Date; value: number }[] {
  const now = Date.now();
  const interval = 60_000; // 1 minute per point
  const data: { timestamp: Date; value: number }[] = [];
  let price = 0;

  for (let i = points - 1; i >= 0; i--) {
    price += (Math.random() - 0.5) * 0.08;
    price = Math.max(-3.5, Math.min(2.5, price));
    data.push({
      timestamp: new Date(now - i * interval),
      value: Math.round(price * 10000) / 10000,
    });
  }

  return data;
}

router.get("/chart", async (req, res) => {
  const assetId = parseInt(req.query.assetId as string);
  const timeframe = (req.query.timeframe as string) ?? "1m";

  if (!assetId || isNaN(assetId)) {
    res.status(400).json({ error: "assetId is required" });
    return;
  }

  const timeframePoints: Record<string, number> = {
    "1m": 60,
    "5m": 60,
    "15m": 60,
    "1h": 60,
    "4h": 60,
  };

  const points = timeframePoints[timeframe] ?? 60;

  const [asset] = await db.select().from(assetsTable).where(eq(assetsTable.id, assetId)).limit(1);
  if (!asset) {
    res.status(404).json({ error: "Asset not found" });
    return;
  }

  const history = generatePriceHistory(parseFloat(asset.currentPrice), points);

  res.json(history.map((h) => ({ timestamp: h.timestamp.toISOString(), value: h.value })));
});

router.get("/price", async (req, res) => {
  const assetId = parseInt(req.query.assetId as string);

  if (!assetId || isNaN(assetId)) {
    res.status(400).json({ error: "assetId is required" });
    return;
  }

  const [asset] = await db.select().from(assetsTable).where(eq(assetsTable.id, assetId)).limit(1);
  if (!asset) {
    res.status(404).json({ error: "Asset not found" });
    return;
  }

  // Simulate small price movement
  const drift = (Math.random() - 0.5) * 0.001;
  const newPrice = parseFloat(asset.currentPrice) + drift;

  // Update the asset price
  await db
    .update(assetsTable)
    .set({
      currentPrice: newPrice.toFixed(4),
      change: drift.toFixed(4),
      changePercent: ((drift / parseFloat(asset.currentPrice)) * 100).toFixed(4),
      updatedAt: new Date(),
    })
    .where(eq(assetsTable.id, assetId));

  res.json({
    assetId,
    price: parseFloat(newPrice.toFixed(4)),
    timestamp: new Date().toISOString(),
  });
});

export default router;
