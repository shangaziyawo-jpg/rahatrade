import { setAuthTokenGetter } from "@workspace/api-client-react";

export const initAuth = () => {
  setAuthTokenGetter(() => {
    return localStorage.getItem("rahatrade_token");
  });
};

export const setToken = (token: string) => {
  localStorage.setItem("rahatrade_token", token);
};

export const clearToken = () => {
  localStorage.removeItem("rahatrade_token");
};

export const getToken = () => {
  return localStorage.getItem("rahatrade_token");
};
