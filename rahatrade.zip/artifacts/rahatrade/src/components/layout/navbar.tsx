import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { TrendingUp, LogOut, Wallet, User as UserIcon, ArrowDownToLine, PlusCircle } from "lucide-react";
import { useGetBalance } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import DepositModal from "../../pages/trade/deposit-modal";
import WithdrawModal from "../../pages/trade/withdraw-modal";
import { useState } from "react";

export default function Navbar() {
  const { user, logout } = useAuth();
  const { data: balance, isLoading } = useGetBalance();
  const [depositOpen, setDepositOpen] = useState(false);
  const [withdrawOpen, setWithdrawOpen] = useState(false);

  return (
    <>
      <header className="h-14 border-b border-border/40 bg-card flex items-center justify-between px-3 sm:px-4 sticky top-0 z-40 shrink-0">
        <div className="flex items-center gap-3">
          <Link href="/trade" className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            <span className="font-bold text-lg tracking-tight hidden sm:inline-block">RahaTrade</span>
          </Link>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex flex-col items-end">
            <div className="text-[10px] text-muted-foreground uppercase tracking-wider hidden xs:block">Balance</div>
            {isLoading ? (
              <Skeleton className="h-5 w-20" />
            ) : (
              <div className="font-mono text-sm sm:text-base font-bold text-primary">
                KES {balance?.balance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || "0.00"}
              </div>
            )}
          </div>

          <Button
            variant="default"
            size="sm"
            className="h-8 px-3 text-xs sm:text-sm gap-1"
            onClick={() => setDepositOpen(true)}
          >
            <PlusCircle className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Deposit</span>
            <span className="sm:hidden">+</span>
          </Button>

          <Button
            variant="outline"
            size="sm"
            className="h-8 px-3 text-xs sm:text-sm gap-1"
            onClick={() => setWithdrawOpen(true)}
          >
            <ArrowDownToLine className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Withdraw</span>
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-9 w-9 rounded-full p-0">
                <Avatar className="h-8 w-8 border border-border/50">
                  <AvatarFallback className="bg-primary/10 text-primary text-sm">
                    {user?.name?.charAt(0).toUpperCase() || <UserIcon className="h-4 w-4" />}
                  </AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-52" align="end" forceMount>
              <DropdownMenuLabel className="font-normal">
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-medium leading-none">{user?.name}</p>
                  <p className="text-xs leading-none text-muted-foreground">{user?.email}</p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <Link href="/history">
                <DropdownMenuItem className="cursor-pointer">
                  <Wallet className="mr-2 h-4 w-4" />
                  <span>Trade History</span>
                </DropdownMenuItem>
              </Link>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={logout} className="text-destructive cursor-pointer focus:bg-destructive/10">
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>

      <DepositModal open={depositOpen} onOpenChange={setDepositOpen} />
      <WithdrawModal open={withdrawOpen} onOpenChange={setWithdrawOpen} />
    </>
  );
}
