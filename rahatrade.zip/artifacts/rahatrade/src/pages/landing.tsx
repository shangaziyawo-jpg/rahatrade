import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, BarChart2, Shield, Zap, TrendingUp } from "lucide-react";
import { motion } from "framer-motion";

export default function Landing() {
  return (
    <div className="min-h-[100dvh] flex flex-col">
      <header className="border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container flex h-16 max-w-screen-2xl items-center justify-between">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-6 w-6 text-primary" />
            <span className="font-bold text-xl tracking-tight">RahaTrade</span>
          </div>
          <nav className="flex items-center gap-4">
            <Link href="/login" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Sign In
            </Link>
            <Link href="/register">
              <Button>Start Trading</Button>
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative overflow-hidden py-20 md:py-32">
          <div className="absolute inset-0 bg-grid-white/[0.02] bg-[length:32px_32px]" />
          <div className="absolute inset-0 bg-gradient-to-b from-background via-background/80 to-background" />
          
          <div className="container relative z-10 mx-auto px-4 md:px-6 text-center max-w-5xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-6">
                Trade Binary Options with <span className="text-primary">Confidence</span>
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto">
                The premier trading terminal for Kenyan retail traders. 
                Fast execution, high payouts, and deep liquidity right at your fingertips.
              </p>
              
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Link href="/register">
                  <Button size="lg" className="w-full sm:w-auto h-14 px-8 text-lg">
                    Start Trading Now <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Link href="/login">
                  <Button variant="outline" size="lg" className="w-full sm:w-auto h-14 px-8 text-lg">
                    Sign In
                  </Button>
                </Link>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Stats Bar */}
        <section className="border-y border-border/50 bg-muted/30">
          <div className="container mx-auto px-4 py-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 divide-y md:divide-y-0 md:divide-x divide-border/50 text-center">
              <div className="flex flex-col py-4 md:py-0">
                <span className="text-4xl font-bold text-up mb-2">85%</span>
                <span className="text-sm font-medium text-muted-foreground tracking-wider uppercase">Max Payout</span>
              </div>
              <div className="flex flex-col py-4 md:py-0">
                <span className="text-4xl font-bold text-foreground mb-2">KES</span>
                <span className="text-sm font-medium text-muted-foreground tracking-wider uppercase">Local Currency</span>
              </div>
              <div className="flex flex-col py-4 md:py-0">
                <span className="text-4xl font-bold text-primary mb-2">30s</span>
                <span className="text-sm font-medium text-muted-foreground tracking-wider uppercase">Min Duration</span>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 md:py-32">
          <div className="container mx-auto px-4 md:px-6">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Professional Tools for Everyone</h2>
              <p className="text-muted-foreground text-lg">
                Built to provide the speed and precision required in modern markets.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-card border border-border/50 rounded-xl p-8 hover-elevate transition-all">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-6">
                  <Zap className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Lightning Execution</h3>
                <p className="text-muted-foreground">
                  Zero latency trading. Enter and exit positions at the exact price you want, when you want.
                </p>
              </div>

              <div className="bg-card border border-border/50 rounded-xl p-8 hover-elevate transition-all">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-6">
                  <BarChart2 className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Advanced Charting</h3>
                <p className="text-muted-foreground">
                  High-performance live charts with multiple timeframes and deep market analysis tools.
                </p>
              </div>

              <div className="bg-card border border-border/50 rounded-xl p-8 hover-elevate transition-all">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-6">
                  <Shield className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Secure Platform</h3>
                <p className="text-muted-foreground">
                  Bank-grade security protecting your funds. Instant M-Pesa deposits and fast withdrawals.
                </p>
              </div>
            </div>
          </div>
        </section>

      </main>

      <footer className="border-t border-border/40 py-8 bg-muted/20">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p className="mb-2">Trading binary options involves significant risk and can result in the loss of your invested capital.</p>
          <p>&copy; {new Date().getFullYear()} RahaTrade. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
