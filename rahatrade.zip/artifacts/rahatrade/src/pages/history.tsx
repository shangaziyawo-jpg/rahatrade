import Navbar from "@/components/layout/navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useGetTrades, useGetTradeSummary } from "@workspace/api-client-react";
import { ArrowUp, ArrowDown, TrendingUp, TrendingDown, Target, Wallet } from "lucide-react";
import { format } from "date-fns";

export default function History() {
  const { data: trades = [], isLoading: isLoadingTrades } = useGetTrades();
  const { data: summary, isLoading: isLoadingSummary } = useGetTradeSummary();

  const closedTrades = trades.filter(t => t.status !== 'open');

  return (
    <div className="flex flex-col min-h-[100dvh] bg-background">
      <Navbar />
      
      <main className="flex-1 container max-w-6xl mx-auto p-4 md:p-6 lg:p-8 space-y-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-2">Trade History</h1>
          <p className="text-muted-foreground">View your past trades and performance analytics.</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="bg-card/50 border-border/50">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Win Rate</CardTitle>
              <Target className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoadingSummary ? "-" : `${(summary?.winRate || 0) * 100}%`}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {summary?.wonTrades || 0} won out of {summary?.totalTrades || 0} total
              </p>
            </CardContent>
          </Card>
          
          <Card className="bg-card/50 border-border/50">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Net Profit</CardTitle>
              {(summary?.netProfit || 0) >= 0 ? (
                <TrendingUp className="h-4 w-4 text-up" />
              ) : (
                <TrendingDown className="h-4 w-4 text-down" />
              )}
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold font-mono ${(summary?.netProfit || 0) >= 0 ? 'text-up' : 'text-down'}`}>
                {isLoadingSummary ? "-" : `${(summary?.netProfit || 0) >= 0 ? '+' : ''}KES ${Math.abs(summary?.netProfit || 0).toLocaleString()}`}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Total profit minus losses
              </p>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-border/50">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Staked</CardTitle>
              <Wallet className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold font-mono">
                {isLoadingSummary ? "-" : `KES ${(summary?.totalStaked || 0).toLocaleString()}`}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Amount risked in all trades
              </p>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-border/50">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Payout</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold font-mono">
                {isLoadingSummary ? "-" : `KES ${(summary?.totalPayout || 0).toLocaleString()}`}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Returns from won trades
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Trades Table */}
        <Card className="bg-card/50 border-border/50 overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead>Time</TableHead>
                  <TableHead>Asset</TableHead>
                  <TableHead>Direction</TableHead>
                  <TableHead>Stake</TableHead>
                  <TableHead>Entry / Exit</TableHead>
                  <TableHead>Result</TableHead>
                  <TableHead className="text-right">Payout</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoadingTrades ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-12 text-muted-foreground">
                      Loading trades...
                    </TableCell>
                  </TableRow>
                ) : closedTrades.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-12 text-muted-foreground">
                      No trading history found.
                    </TableCell>
                  </TableRow>
                ) : (
                  closedTrades.map((trade: any) => (
                    <TableRow key={trade.id}>
                      <TableCell className="text-sm text-muted-foreground whitespace-nowrap">
                        {format(new Date(trade.createdAt), 'MMM d, yyyy')}
                        <br />
                        {format(new Date(trade.createdAt), 'HH:mm:ss')}
                      </TableCell>
                      <TableCell className="font-semibold">{trade.assetName}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={trade.direction === 'UP' ? 'text-up border-up/30 bg-up/5' : 'text-down border-down/30 bg-down/5'}>
                          {trade.direction === 'UP' ? <ArrowUp className="h-3 w-3 mr-1" /> : <ArrowDown className="h-3 w-3 mr-1" />}
                          {trade.direction}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-mono text-muted-foreground">KES {trade.amount.toLocaleString()}</TableCell>
                      <TableCell className="font-mono text-sm">
                        <div className="text-muted-foreground">{trade.entryPrice.toFixed(4)}</div>
                        <div>{trade.closingPrice?.toFixed(4) || '-'}</div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={trade.status === 'won' ? 'default' : 'destructive'} className={trade.status === 'won' ? 'bg-up hover:bg-up text-up-foreground' : 'bg-down hover:bg-down text-down-foreground'}>
                          {trade.status.toUpperCase()}
                        </Badge>
                      </TableCell>
                      <TableCell className={`text-right font-mono font-bold ${trade.status === 'won' ? 'text-up' : 'text-muted-foreground'}`}>
                        {trade.status === 'won' ? `+ KES ${trade.payout.toLocaleString()}` : '0'}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </Card>

      </main>
    </div>
  );
}
