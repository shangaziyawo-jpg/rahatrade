import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useCreateWithdrawal, getGetBalanceQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Smartphone, Loader2, CheckCircle2, ArrowDownToLine, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useGetBalance } from "@workspace/api-client-react";

export default function WithdrawModal({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const [step, setStep] = useState(1);
  const [amount, setAmount] = useState<number | "">("");
  const [phone, setPhone] = useState("");

  const createWithdrawal = useCreateWithdrawal();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { data: balance } = useGetBalance();

  const handleReset = () => {
    setStep(1);
    setAmount("");
    setPhone("");
  };

  const handleClose = () => {
    onOpenChange(false);
    setTimeout(handleReset, 300);
  };

  const handleSubmit = () => {
    const amt = Number(amount);
    if (!amt || amt < 100) {
      toast({ title: "Invalid amount", description: "Minimum withdrawal is KES 100", variant: "destructive" });
      return;
    }
    if (balance && amt > balance.balance) {
      toast({ title: "Insufficient balance", description: `You only have KES ${balance.balance.toLocaleString()}`, variant: "destructive" });
      return;
    }
    if (!phone || phone.length < 9) {
      toast({ title: "Invalid phone", description: "Please enter a valid M-Pesa number", variant: "destructive" });
      return;
    }

    createWithdrawal.mutate(
      { data: { amount: amt, mpesaPhone: phone } },
      {
        onSuccess: () => {
          setStep(3);
          queryClient.invalidateQueries({ queryKey: getGetBalanceQueryKey() });
        },
        onError: (err) => {
          toast({ title: "Withdrawal failed", description: err.message || "Something went wrong", variant: "destructive" });
        },
      }
    );
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md mx-4">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ArrowDownToLine className="h-5 w-5 text-primary" />
            Withdraw Funds
          </DialogTitle>
          <DialogDescription>
            {step === 1 && "Enter withdrawal amount and M-Pesa number."}
            {step === 3 && "Withdrawal request submitted."}
          </DialogDescription>
        </DialogHeader>

        <div className="py-2">
          {step === 1 && (
            <div className="space-y-5">
              {balance && (
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/40 border border-border/50">
                  <span className="text-sm text-muted-foreground">Available Balance</span>
                  <span className="font-mono font-bold text-primary">
                    KES {balance.balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>
              )}

              <div className="space-y-2">
                <label className="text-sm font-medium">Quick Select (KES)</label>
                <div className="grid grid-cols-4 gap-2">
                  {[500, 1000, 2500, 5000].map((val) => (
                    <Button
                      key={val}
                      type="button"
                      variant={amount === val ? "default" : "outline"}
                      size="sm"
                      onClick={() => setAmount(val)}
                      className="w-full"
                    >
                      {val >= 1000 ? `${val / 1000}k` : val}
                    </Button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Amount (KES)</label>
                <Input
                  type="number"
                  placeholder="Min 100"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value ? Number(e.target.value) : "")}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-2">
                  <Smartphone className="h-4 w-4 text-primary" />
                  M-Pesa Phone Number
                </label>
                <Input
                  type="tel"
                  placeholder="07XX XXX XXX"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                />
              </div>

              <div className="flex items-start gap-2 text-xs text-muted-foreground bg-muted/30 rounded-lg p-3">
                <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                <span>Funds will be sent to your M-Pesa within 5–30 minutes. Minimum withdrawal is KES 100.</span>
              </div>

              <Button
                className="w-full h-12"
                onClick={handleSubmit}
                disabled={createWithdrawal.isPending}
              >
                {createWithdrawal.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : null}
                Request Withdrawal
              </Button>
            </div>
          )}

          {step === 3 && (
            <div className="text-center space-y-4 py-6">
              <div className="mx-auto w-16 h-16 bg-up/20 rounded-full flex items-center justify-center mb-4">
                <CheckCircle2 className="h-8 w-8 text-up" />
              </div>
              <h3 className="text-xl font-semibold">Withdrawal Submitted!</h3>
              <p className="text-muted-foreground text-sm">
                KES {Number(amount).toLocaleString()} will be sent to {phone} via M-Pesa within 5–30 minutes.
              </p>
              <Button className="w-full mt-4" onClick={handleClose}>
                Done
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
