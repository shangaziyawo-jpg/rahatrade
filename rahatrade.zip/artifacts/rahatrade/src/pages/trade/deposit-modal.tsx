import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useCreateDeposit, getGetBalanceQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Smartphone, ChevronRight, Loader2, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function DepositModal({ open, onOpenChange }: { open: boolean, onOpenChange: (open: boolean) => void }) {
  const [step, setStep] = useState(1);
  const [amount, setAmount] = useState<number | "">("");
  const [phone, setPhone] = useState("");
  
  const createDeposit = useCreateDeposit();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleReset = () => {
    setStep(1);
    setAmount("");
    setPhone("");
  };

  const handleClose = () => {
    onOpenChange(false);
    setTimeout(handleReset, 300);
  };

  const handleSubmit = () => {
    if (!amount || amount < 100) {
      toast({ title: "Invalid amount", description: "Minimum deposit is KES 100", variant: "destructive" });
      return;
    }
    if (!phone || phone.length < 9) {
      toast({ title: "Invalid phone", description: "Please enter a valid M-Pesa number", variant: "destructive" });
      return;
    }

    createDeposit.mutate(
      { data: { amount: Number(amount), mpesaPhone: phone } },
      {
        onSuccess: () => {
          setStep(3);
          queryClient.invalidateQueries({ queryKey: getGetBalanceQueryKey() });
        },
        onError: (err) => {
          toast({ title: "Deposit failed", description: err.message || "Something went wrong", variant: "destructive" });
        }
      }
    );
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Deposit Funds</DialogTitle>
          <DialogDescription>
            {step === 1 && "Select your preferred payment method."}
            {step === 2 && "Enter amount and M-Pesa phone number."}
            {step === 3 && "Deposit initiated."}
          </DialogDescription>
        </DialogHeader>

        <div className="py-4">
          {step === 1 && (
            <div className="space-y-4">
              <button 
                onClick={() => setStep(2)}
                className="w-full flex items-center justify-between p-4 rounded-xl border border-primary bg-primary/5 hover:bg-primary/10 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className="h-10 w-10 bg-primary/20 rounded-full flex items-center justify-center">
                    <Smartphone className="h-5 w-5 text-primary" />
                  </div>
                  <div className="text-left">
                    <div className="font-semibold">M-Pesa</div>
                    <div className="text-sm text-muted-foreground">Instant deposit</div>
                  </div>
                </div>
                <ChevronRight className="h-5 w-5 text-muted-foreground" />
              </button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-medium">Quick Select Amount (KES)</label>
                <div className="grid grid-cols-4 gap-2">
                  {[500, 1000, 2500, 5000].map(val => (
                    <Button 
                      key={val} 
                      type="button" 
                      variant={amount === val ? "default" : "outline"}
                      onClick={() => setAmount(val)}
                      className="w-full"
                    >
                      {val >= 1000 ? `${val/1000}k` : val}
                    </Button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Custom Amount (KES)</label>
                <Input 
                  type="number" 
                  placeholder="Min 100" 
                  value={amount} 
                  onChange={(e) => setAmount(e.target.value ? Number(e.target.value) : "")} 
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">M-Pesa Phone Number</label>
                <Input 
                  placeholder="07XX XXX XXX" 
                  value={phone} 
                  onChange={(e) => setPhone(e.target.value)} 
                />
              </div>

              <Button 
                className="w-full" 
                onClick={handleSubmit}
                disabled={createDeposit.isPending}
              >
                {createDeposit.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                Proceed to Pay
              </Button>
              <Button variant="ghost" className="w-full" onClick={() => setStep(1)} disabled={createDeposit.isPending}>
                Back
              </Button>
            </div>
          )}

          {step === 3 && (
            <div className="text-center space-y-4 py-6">
              <div className="mx-auto w-16 h-16 bg-up/20 rounded-full flex items-center justify-center mb-4">
                <CheckCircle2 className="h-8 w-8 text-up" />
              </div>
              <h3 className="text-xl font-semibold">Deposit Processing</h3>
              <p className="text-muted-foreground text-sm">
                Your deposit of KES {Number(amount).toLocaleString()} is being processed. 
                You will receive an M-Pesa prompt shortly on your phone to enter your PIN.
              </p>
              <Button className="w-full mt-4" onClick={handleClose}>
                Done
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
