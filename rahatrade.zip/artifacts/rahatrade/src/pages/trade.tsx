import { useState, useEffect, useRef } from "react";
import Navbar from "@/components/layout/navbar";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  useGetAssets,
  usePlaceTrade,
  useGetOpenTrades,
  useGetTrades,
  getGetBalanceQueryKey,
  getGetOpenTradesQueryKey,
  getGetTradesQueryKey,
  useGetLatestPrice,
  getGetLatestPriceQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { TrendingUp, TrendingDown, Clock, Loader2, ChevronDown } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from "recharts";
import { format } from "date-fns";

const TIMEFRAMES = [
  { label: "30s", value: 30 },
  { label: "1m", value: 60 },
  { label: "5m", value: 300 },
  { label: "15m", value: 900 },
  { label: "1h", value: 3600 },
];

const QUICK_AMOUNTS = [100, 500, 1000, 5000];

export default function Trade() {
  const { data: assets = [], isLoading: isLoadingAssets } = useGetAssets();
  const [selectedAssetId, setSelectedAssetId] = useState<number | null>(null);
  const [amount, setAmount] = useState<number>(500);
  const [duration, setDuration] = useState<number>(60);
  const [panelOpen, setPanelOpen] = useState(false);

  const placeTrade = usePlaceTrade();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: openTrades = [] } = useGetOpenTrades({
    query: { refetchInterval: 1000 },
  });

  const { data: allTrades = [] } = useGetTrades();

  const selectedAsset = assets.find((a) => a.id === selectedAssetId) || assets[0];

  useEffect(() => {
    if (!selectedAssetId && assets.length > 0) {
      setSelectedAssetId(assets[0].id);
    }
  }, [assets, selectedAssetId]);

  const [chartData, setChartData] = useState<{ time: number; price: number }[]>([]);
  const latestPrice = useRef(selectedAsset?.currentPrice || 100);

  const { data: livePriceData } = useGetLatestPrice(
    { assetId: selectedAssetId || 1 },
    {
      query: {
        enabled: !!selectedAssetId,
        refetchInterval: 2000,
        queryKey: getGetLatestPriceQueryKey({ assetId: selectedAssetId || 1 }),
      },
    }
  );

  useEffect(() => {
    if (livePriceData?.price) {
      latestPrice.current = livePriceData.price;
    }
  }, [livePriceData]);

  useEffect(() => {
    if (!selectedAsset) return;
    const initial = Array.from({ length: 60 }).map((_, i) => ({
      time: Date.now() - (60 - i) * 1000,
      price: latestPrice.current + (Math.random() - 0.5) * 2,
    }));
    setChartData(initial);

    const interval = setInterval(() => {
      setChartData((prev) => {
        const next = [...prev.slice(1)];
        const last = next[next.length - 1]?.price || latestPrice.current;
        const diff = latestPrice.current - last;
        next.push({ time: Date.now(), price: last + diff * 0.1 + (Math.random() - 0.5) * 0.5 });
        return next;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [selectedAsset?.id]);

  const handlePlaceTrade = (direction: "UP" | "DOWN") => {
    if (!selectedAsset) return;
    placeTrade.mutate(
      { data: { assetId: selectedAsset.id, direction, amount, duration } },
      {
        onSuccess: () => {
          toast({ title: direction === "UP" ? "📈 BUY placed!" : "📉 SELL placed!", description: "Good luck!" });
          queryClient.invalidateQueries({ queryKey: getGetBalanceQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetOpenTradesQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetTradesQueryKey() });
          setPanelOpen(false);
        },
        onError: (err) => {
          toast({ variant: "destructive", title: "Trade failed", description: err.message || "Failed to place trade" });
        },
      }
    );
  };

  const payoutRate = 0.85;
  const potentialPayout = amount + amount * payoutRate;
  const currentPrice = chartData[chartData.length - 1]?.price || selectedAsset?.currentPrice || 0;
  const startPrice = chartData[0]?.price || currentPrice;
  const isUp = currentPrice >= startPrice;

  const TradingPanel = () => (
    <div className="space-y-4 p-4">
      <div className="space-y-1.5">
        <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Asset</label>
        <Select
          value={selectedAssetId?.toString()}
          onValueChange={(v) => setSelectedAssetId(Number(v))}
        >
          <SelectTrigger className="w-full h-11 bg-background border-border/50">
            <SelectValue placeholder="Select Asset" />
          </SelectTrigger>
          <SelectContent>
            {assets.map((a) => (
              <SelectItem key={a.id} value={a.id.toString()}>
                <div className="flex items-center justify-between w-full min-w-[200px]">
                  <span className="font-semibold">{a.name}</span>
                  <span className={`text-sm ml-4 ${a.changePercent >= 0 ? "text-up" : "text-down"}`}>
                    {a.changePercent >= 0 ? "+" : ""}{a.changePercent}%
                  </span>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Duration</label>
          <Select value={duration.toString()} onValueChange={(v) => setDuration(Number(v))}>
            <SelectTrigger className="h-11 bg-background border-border/50">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {TIMEFRAMES.map((t) => (
                <SelectItem key={t.value} value={t.value.toString()}>
                  {t.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Amount (KES)</label>
          <Input
            type="number"
            value={amount}
            onChange={(e) => setAmount(Math.max(10, Number(e.target.value)))}
            className="h-11 text-center font-mono font-bold bg-background border-border/50"
          />
        </div>
      </div>

      <div className="grid grid-cols-4 gap-1.5">
        {QUICK_AMOUNTS.map((a) => (
          <Button
            key={a}
            variant={amount === a ? "default" : "outline"}
            size="sm"
            className="h-8 text-xs"
            onClick={() => setAmount(a)}
          >
            {a >= 1000 ? `${a / 1000}k` : a}
          </Button>
        ))}
      </div>

      <Card className="p-3 bg-muted/20 border-border/50">
        <div className="flex justify-between items-center mb-1">
          <span className="text-xs text-muted-foreground">Payout (85%)</span>
          <span className="font-mono text-sm font-bold text-up">
            +KES {(amount * payoutRate).toLocaleString(undefined, { maximumFractionDigits: 0 })}
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-xs text-muted-foreground">If win</span>
          <span className="font-mono text-base font-bold">
            KES {potentialPayout.toLocaleString(undefined, { maximumFractionDigits: 0 })}
          </span>
        </div>
      </Card>

      <div className="grid grid-cols-2 gap-3">
        <Button
          onClick={() => handlePlaceTrade("UP")}
          disabled={placeTrade.isPending}
          className="h-14 text-base font-bold bg-up hover:bg-up/90 text-up-foreground shadow-lg shadow-up/20 active:scale-[0.97] transition-transform"
        >
          {placeTrade.isPending ? (
            <Loader2 className="h-5 w-5 animate-spin" />
          ) : (
            <>
              <TrendingUp className="mr-1.5 h-5 w-5" />
              BUY
            </>
          )}
        </Button>
        <Button
          onClick={() => handlePlaceTrade("DOWN")}
          disabled={placeTrade.isPending}
          className="h-14 text-base font-bold bg-down hover:bg-down/90 text-down-foreground shadow-lg shadow-down/20 active:scale-[0.97] transition-transform"
        >
          {placeTrade.isPending ? (
            <Loader2 className="h-5 w-5 animate-spin" />
          ) : (
            <>
              <TrendingDown className="mr-1.5 h-5 w-5" />
              SELL
            </>
          )}
        </Button>
      </div>
    </div>
  );

  return (
    <div className="flex flex-col h-[100dvh] overflow-hidden bg-background">
      <Navbar />

      {/* === DESKTOP LAYOUT (lg+) === */}
      <div className="hidden lg:flex flex-1 overflow-hidden">
        {/* Left sidebar */}
        <div className="w-72 xl:w-80 border-r border-border/40 bg-card/50 overflow-y-auto">
          <TradingPanel />
        </div>

        {/* Chart + bottom panel */}
        <div className="flex-1 flex flex-col min-w-0">
          <ChartHeader
            selectedAsset={selectedAsset}
            currentPrice={currentPrice}
            isUp={isUp}
          />
          <div className="flex-1 min-h-[200px] p-3">
            <TradeChart chartData={chartData} isUp={isUp} startPrice={startPrice} />
          </div>
          <BottomTabs openTrades={openTrades} allTrades={allTrades} />
        </div>
      </div>

      {/* === MOBILE LAYOUT (< lg) === */}
      <div className="lg:hidden flex flex-col flex-1 overflow-hidden">
        {/* Chart area — fixed height on mobile */}
        <div className="shrink-0">
          <ChartHeader
            selectedAsset={selectedAsset}
            currentPrice={currentPrice}
            isUp={isUp}
          />
          <div className="h-[200px] sm:h-[250px]">
            <TradeChart chartData={chartData} isUp={isUp} startPrice={startPrice} />
          </div>
        </div>

        {/* Scrollable content below chart */}
        <div className="flex-1 overflow-y-auto">
          {/* Collapsible trading panel */}
          <div className="border-b border-border/40">
            <button
              className="w-full flex items-center justify-between px-4 py-3 bg-card/50 text-sm font-medium"
              onClick={() => setPanelOpen((v) => !v)}
            >
              <span>Trade Controls</span>
              <ChevronDown
                className={`h-4 w-4 text-muted-foreground transition-transform ${panelOpen ? "rotate-180" : ""}`}
              />
            </button>
            {panelOpen && (
              <div className="bg-card/30">
                <TradingPanel />
              </div>
            )}
          </div>

          {/* Quick BUY/SELL always visible on mobile */}
          {!panelOpen && (
            <div className="px-4 py-3 bg-card/30 border-b border-border/40 space-y-2">
              <div className="grid grid-cols-2 gap-2 mb-2">
                {QUICK_AMOUNTS.map((a) => (
                  <Button
                    key={a}
                    variant={amount === a ? "default" : "outline"}
                    size="sm"
                    className="h-8 text-xs"
                    onClick={() => setAmount(a)}
                  >
                    KES {a >= 1000 ? `${a / 1000}k` : a}
                  </Button>
                ))}
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Button
                  onClick={() => handlePlaceTrade("UP")}
                  disabled={placeTrade.isPending}
                  className="h-14 text-base font-bold bg-up hover:bg-up/90 text-up-foreground active:scale-[0.97] transition-transform"
                >
                  {placeTrade.isPending ? (
                    <Loader2 className="h-5 w-5 animate-spin" />
                  ) : (
                    <>
                      <TrendingUp className="mr-1.5 h-5 w-5" />
                      BUY
                    </>
                  )}
                </Button>
                <Button
                  onClick={() => handlePlaceTrade("DOWN")}
                  disabled={placeTrade.isPending}
                  className="h-14 text-base font-bold bg-down hover:bg-down/90 text-down-foreground active:scale-[0.97] transition-transform"
                >
                  {placeTrade.isPending ? (
                    <Loader2 className="h-5 w-5 animate-spin" />
                  ) : (
                    <>
                      <TrendingDown className="mr-1.5 h-5 w-5" />
                      SELL
                    </>
                  )}
                </Button>
              </div>
              <div className="flex justify-between text-xs text-muted-foreground px-1">
                <span>85% payout</span>
                <span className="font-mono text-up font-semibold">
                  Win: KES {potentialPayout.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                </span>
              </div>
            </div>
          )}

          <BottomTabs openTrades={openTrades} allTrades={allTrades} mobile />
        </div>
      </div>
    </div>
  );
}

function ChartHeader({
  selectedAsset,
  currentPrice,
  isUp,
}: {
  selectedAsset: any;
  currentPrice: number;
  isUp: boolean;
}) {
  return (
    <div className="h-12 border-b border-border/40 px-4 flex items-center justify-between shrink-0">
      <div className="flex items-center gap-3">
        <h2 className="text-base font-bold truncate max-w-[120px] sm:max-w-none">
          {selectedAsset?.name || "Loading..."}
        </h2>
        <span className={`text-base font-mono font-bold ${isUp ? "text-up" : "text-down"}`}>
          {currentPrice.toFixed(4)}
        </span>
        {selectedAsset && (
          <Badge
            variant="outline"
            className={`text-xs font-mono hidden sm:inline-flex ${
              selectedAsset.changePercent >= 0
                ? "text-up border-up/30 bg-up/10"
                : "text-down border-down/30 bg-down/10"
            }`}
          >
            {selectedAsset.changePercent >= 0 ? "+" : ""}
            {selectedAsset.changePercent}%
          </Badge>
        )}
      </div>
      <div className={`text-xs font-medium px-2 py-1 rounded ${isUp ? "bg-up/10 text-up" : "bg-down/10 text-down"}`}>
        {isUp ? "▲ UP" : "▼ DOWN"}
      </div>
    </div>
  );
}

function TradeChart({
  chartData,
  isUp,
  startPrice,
}: {
  chartData: { time: number; price: number }[];
  isUp: boolean;
  startPrice: number;
}) {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart data={chartData} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
        <defs>
          <linearGradient id="colorUp" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="hsl(var(--up))" stopOpacity={0.3} />
            <stop offset="95%" stopColor="hsl(var(--up))" stopOpacity={0} />
          </linearGradient>
          <linearGradient id="colorDown" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="hsl(var(--down))" stopOpacity={0.3} />
            <stop offset="95%" stopColor="hsl(var(--down))" stopOpacity={0} />
          </linearGradient>
        </defs>
        <XAxis
          dataKey="time"
          type="number"
          domain={["dataMin", "dataMax"]}
          tickFormatter={(t) => format(new Date(t), "HH:mm:ss")}
          stroke="hsl(var(--muted-foreground))"
          tick={{ fontSize: 10 }}
          minTickGap={60}
        />
        <YAxis
          domain={["auto", "auto"]}
          stroke="hsl(var(--muted-foreground))"
          tick={{ fontSize: 10, fontFamily: "monospace" }}
          orientation="right"
          tickFormatter={(val) => val.toFixed(2)}
          width={55}
        />
        <Tooltip
          contentStyle={{ backgroundColor: "hsl(var(--card))", borderColor: "hsl(var(--border))", fontSize: 12 }}
          labelFormatter={(l) => format(new Date(l), "HH:mm:ss")}
          formatter={(val: number) => [val.toFixed(4), "Price"]}
        />
        <ReferenceLine y={startPrice} stroke="hsl(var(--muted-foreground))" strokeDasharray="3 3" />
        <Area
          type="monotone"
          dataKey="price"
          stroke={isUp ? "hsl(var(--up))" : "hsl(var(--down))"}
          strokeWidth={2}
          fillOpacity={1}
          fill={isUp ? "url(#colorUp)" : "url(#colorDown)"}
          isAnimationActive={false}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}

function BottomTabs({ openTrades, allTrades, mobile }: { openTrades: any[]; allTrades: any[]; mobile?: boolean }) {
  return (
    <div className={mobile ? "" : "h-52 border-t border-border/40 bg-card/50 flex flex-col shrink-0"}>
      <Tabs defaultValue="open" className="w-full h-full flex flex-col">
        <TabsList
          className={`w-full justify-start rounded-none border-b border-border/40 h-10 bg-transparent px-3 ${
            mobile ? "" : ""
          }`}
        >
          <TabsTrigger
            value="open"
            className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none h-full px-4 text-sm"
          >
            Open ({openTrades.length})
          </TabsTrigger>
          <TabsTrigger
            value="history"
            className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none h-full px-4 text-sm"
          >
            History
          </TabsTrigger>
        </TabsList>

        <TabsContent value="open" className="flex-1 overflow-auto p-0 m-0">
          <Table>
            <TableHeader className="sticky top-0 bg-card/90 backdrop-blur z-10">
              <TableRow>
                <TableHead className="text-xs">Asset</TableHead>
                <TableHead className="text-xs">Dir</TableHead>
                <TableHead className="text-xs">Amount</TableHead>
                <TableHead className="text-xs hidden sm:table-cell">Entry</TableHead>
                <TableHead className="text-xs">Time</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {openTrades.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-6 text-muted-foreground text-sm">
                    No open trades. Place a BUY or SELL above.
                  </TableCell>
                </TableRow>
              ) : (
                openTrades.map((trade: any) => {
                  const timeLeft = Math.max(
                    0,
                    Math.floor((new Date(trade.expiresAt).getTime() - Date.now()) / 1000)
                  );
                  return (
                    <TableRow key={trade.id}>
                      <TableCell className="font-semibold text-xs py-2">{trade.assetName}</TableCell>
                      <TableCell className="py-2">
                        <Badge
                          variant="outline"
                          className={`text-xs ${trade.direction === "UP" ? "text-up border-up/30" : "text-down border-down/30"}`}
                        >
                          {trade.direction === "UP" ? "BUY" : "SELL"}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-mono text-xs py-2">
                        KES {Number(trade.amount).toLocaleString()}
                      </TableCell>
                      <TableCell className="font-mono text-xs py-2 hidden sm:table-cell">
                        {Number(trade.entryPrice).toFixed(4)}
                      </TableCell>
                      <TableCell className="py-2">
                        <div className="flex items-center gap-1 font-mono text-xs text-primary">
                          <Clock className="h-3 w-3" />
                          {timeLeft}s
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </TabsContent>

        <TabsContent value="history" className="flex-1 overflow-auto p-0 m-0">
          <Table>
            <TableHeader className="sticky top-0 bg-card/90 backdrop-blur z-10">
              <TableRow>
                <TableHead className="text-xs">Asset</TableHead>
                <TableHead className="text-xs">Dir</TableHead>
                <TableHead className="text-xs">Amount</TableHead>
                <TableHead className="text-xs">Result</TableHead>
                <TableHead className="text-xs hidden sm:table-cell">Payout</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {allTrades
                .filter((t) => t.status !== "open")
                .slice(0, 15)
                .map((trade: any) => (
                  <TableRow key={trade.id}>
                    <TableCell className="font-semibold text-xs py-2">{trade.assetName}</TableCell>
                    <TableCell className="py-2">
                      <Badge
                        variant="outline"
                        className={`text-xs ${trade.direction === "UP" ? "text-up border-up/30" : "text-down border-down/30"}`}
                      >
                        {trade.direction === "UP" ? "BUY" : "SELL"}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-mono text-xs py-2">
                      KES {Number(trade.amount).toLocaleString()}
                    </TableCell>
                    <TableCell className="py-2">
                      <Badge
                        className={`text-xs ${
                          trade.status === "won"
                            ? "bg-up hover:bg-up text-up-foreground"
                            : "bg-down hover:bg-down text-down-foreground"
                        }`}
                      >
                        {trade.status.toUpperCase()}
                      </Badge>
                    </TableCell>
                    <TableCell
                      className={`font-mono text-xs py-2 font-bold hidden sm:table-cell ${
                        trade.status === "won" ? "text-up" : "text-muted-foreground"
                      }`}
                    >
                      {trade.status === "won"
                        ? `+KES ${Number(trade.payout).toLocaleString()}`
                        : "-"}
                    </TableCell>
                  </TableRow>
                ))}
              {allTrades.filter((t) => t.status !== "open").length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-6 text-muted-foreground text-sm">
                    No completed trades yet
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TabsContent>
      </Tabs>
    </div>
  );
}
