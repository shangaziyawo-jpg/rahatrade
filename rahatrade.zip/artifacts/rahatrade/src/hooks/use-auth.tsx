import { useQueryClient } from "@tanstack/react-query";
import { clearToken, setToken } from "../lib/auth";
import { useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { useLocation } from "wouter";

export function useAuth() {
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();

  const { data: user, isLoading, error } = useGetMe({
    query: {
      retry: false,
      staleTime: Infinity,
    }
  });

  const isAuthenticated = !!user;

  const login = (token: string) => {
    setToken(token);
    queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
    setLocation("/trade");
  };

  const logout = () => {
    clearToken();
    queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
    queryClient.setQueryData(getGetMeQueryKey(), null);
    setLocation("/login");
  };

  return {
    user,
    isAuthenticated,
    isLoading,
    login,
    logout,
    error
  };
}
