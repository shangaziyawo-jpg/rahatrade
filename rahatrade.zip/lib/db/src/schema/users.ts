import { pgTable, serial, text, timestamp, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const usersTable = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone").notNull(),
  passwordHash: text("password_hash").notNull(),
  balance: numeric("balance", { precision: 14, scale: 2 }).notNull().default("5000.00"),
  accountType: text("account_type").notNull().default("REAL"),
  totalDeposited: numeric("total_deposited", { precision: 14, scale: 2 }).notNull().default("0.00"),
  totalPayout: numeric("total_payout", { precision: 14, scale: 2 }).notNull().default("0.00"),
  totalLost: numeric("total_lost", { precision: 14, scale: 2 }).notNull().default("0.00"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(usersTable).omit({ id: true, createdAt: true, passwordHash: true, balance: true, accountType: true, totalDeposited: true, totalPayout: true, totalLost: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof usersTable.$inferSelect;
