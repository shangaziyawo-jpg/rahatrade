import { pgTable, serial, integer, numeric, timestamp } from "drizzle-orm/pg-core";
import { assetsTable } from "./assets";

export const priceHistoryTable = pgTable("price_history", {
  id: serial("id").primaryKey(),
  assetId: integer("asset_id").notNull().references(() => assetsTable.id),
  price: numeric("price", { precision: 14, scale: 4 }).notNull(),
  timeframe: integer("timeframe").notNull().default(60), // seconds
  recordedAt: timestamp("recorded_at").notNull().defaultNow(),
});

export type PriceHistory = typeof priceHistoryTable.$inferSelect;
