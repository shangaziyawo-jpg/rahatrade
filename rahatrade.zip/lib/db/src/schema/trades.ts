import { pgTable, serial, integer, text, numeric, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";
import { assetsTable } from "./assets";

export const tradesTable = pgTable("trades", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id),
  assetId: integer("asset_id").notNull().references(() => assetsTable.id),
  assetName: text("asset_name").notNull(),
  assetSymbol: text("asset_symbol").notNull(),
  direction: text("direction").notNull(), // UP | DOWN
  amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
  payout: numeric("payout", { precision: 14, scale: 2 }).notNull(),
  payoutPercent: numeric("payout_percent", { precision: 10, scale: 2 }).notNull().default("85.00"),
  entryPrice: numeric("entry_price", { precision: 14, scale: 4 }).notNull(),
  currentPrice: numeric("current_price", { precision: 14, scale: 4 }),
  closingPrice: numeric("closing_price", { precision: 14, scale: 4 }),
  duration: integer("duration").notNull().default(60), // seconds
  status: text("status").notNull().default("open"), // open | won | lost | cancelled
  result: text("result"),
  expiresAt: timestamp("expires_at").notNull(),
  closedAt: timestamp("closed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTradeSchema = createInsertSchema(tradesTable).omit({ id: true, createdAt: true });
export type InsertTrade = z.infer<typeof insertTradeSchema>;
export type Trade = typeof tradesTable.$inferSelect;
